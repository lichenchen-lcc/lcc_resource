//
//  main.m
//  Example
//
//  Created by default on 1/8/14.
//  Copyright (c) 2014 CatalystApps. All rights reserved.
//

#import <UIKit/UIKit.h>


int main(int argc, char * argv[])
{
    NSAutoreleasePool * pool = [[NSAutoreleasePool alloc] init];
    int retVal = UIApplicationMain(argc, argv, nil, @"AppController");
    [pool release];
    return retVal;
}
