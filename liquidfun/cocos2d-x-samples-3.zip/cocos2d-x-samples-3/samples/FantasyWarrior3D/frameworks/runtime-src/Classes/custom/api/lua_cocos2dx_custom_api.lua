--------------------------------
-- @module cc

--------------------------------------------------------
-- the cc ShadowSprite
-- @field [parent=#cc] ShadowSprite#ShadowSprite ShadowSprite preloaded module


--------------------------------------------------------
-- the cc Effect3D
-- @field [parent=#cc] Effect3D#Effect3D Effect3D preloaded module


--------------------------------------------------------
-- the cc Effect3DOutline
-- @field [parent=#cc] Effect3DOutline#Effect3DOutline Effect3DOutline preloaded module


--------------------------------------------------------
-- the cc EffectSprite3D
-- @field [parent=#cc] EffectSprite3D#EffectSprite3D EffectSprite3D preloaded module


--------------------------------------------------------
-- the cc DrawNode3D
-- @field [parent=#cc] DrawNode3D#DrawNode3D DrawNode3D preloaded module


--------------------------------------------------------
-- the cc BillboardParticleSystem
-- @field [parent=#cc] BillboardParticleSystem#BillboardParticleSystem BillboardParticleSystem preloaded module


--------------------------------------------------------
-- the cc JumpBy3D
-- @field [parent=#cc] JumpBy3D#JumpBy3D JumpBy3D preloaded module


--------------------------------------------------------
-- the cc JumpTo3D
-- @field [parent=#cc] JumpTo3D#JumpTo3D JumpTo3D preloaded module


--------------------------------------------------------
-- the cc Water
-- @field [parent=#cc] Water#Water Water preloaded module


--------------------------------------------------------
-- the cc Effect
-- @field [parent=#cc] Effect#Effect Effect preloaded module


--------------------------------------------------------
-- the cc EffectNormalMapped
-- @field [parent=#cc] EffectNormalMapped#EffectNormalMapped EffectNormalMapped preloaded module


--------------------------------------------------------
-- the cc EffectSprite
-- @field [parent=#cc] EffectSprite#EffectSprite EffectSprite preloaded module


--------------------------------------------------------
-- the cc Sequence3D
-- @field [parent=#cc] Sequence3D#Sequence3D Sequence3D preloaded module


--------------------------------------------------------
-- the cc GreyShader
-- @field [parent=#cc] GreyShader#GreyShader GreyShader preloaded module


return nil
