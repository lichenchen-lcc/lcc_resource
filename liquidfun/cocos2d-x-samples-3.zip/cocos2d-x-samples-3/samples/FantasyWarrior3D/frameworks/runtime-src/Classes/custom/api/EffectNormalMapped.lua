
--------------------------------
-- @module EffectNormalMapped
-- @extend Effect
-- @parent_module cc

--------------------------------
-- 
-- @function [parent=#EffectNormalMapped] setKBump 
-- @param self
-- @param #float value
-- @return EffectNormalMapped#EffectNormalMapped self (return value: cc.EffectNormalMapped)
        
--------------------------------
-- 
-- @function [parent=#EffectNormalMapped] setPointLight 
-- @param self
-- @param #point_table pointLight
-- @return EffectNormalMapped#EffectNormalMapped self (return value: cc.EffectNormalMapped)
        
--------------------------------
-- 
-- @function [parent=#EffectNormalMapped] getKBump 
-- @param self
-- @return float#float ret (return value: float)
        
--------------------------------
-- @overload self, string         
-- @overload self         
-- @function [parent=#EffectNormalMapped] create
-- @param self
-- @param #string normalMapFileName
-- @return EffectNormalMapped#EffectNormalMapped ret (return value: cc.EffectNormalMapped)

return nil
