
--------------------------------
-- @module Effect
-- @extend Ref
-- @parent_module cc

--------------------------------
-- 
-- @function [parent=#Effect] setTarget 
-- @param self
-- @param #cc.EffectSprite sprite
-- @return Effect#Effect self (return value: cc.Effect)
        
--------------------------------
-- 
-- @function [parent=#Effect] updateUniforms 
-- @param self
-- @return Effect#Effect self (return value: cc.Effect)
        
--------------------------------
-- 
-- @function [parent=#Effect] getGLProgramState 
-- @param self
-- @return GLProgramState#GLProgramState ret (return value: cc.GLProgramState)
        
return nil
