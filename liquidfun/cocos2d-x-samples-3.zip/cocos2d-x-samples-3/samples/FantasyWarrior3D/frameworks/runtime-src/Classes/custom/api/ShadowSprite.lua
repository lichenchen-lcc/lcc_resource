
--------------------------------
-- @module ShadowSprite
-- @extend Sprite
-- @parent_module cc

--------------------------------
-- 
-- @function [parent=#ShadowSprite] create 
-- @param self
-- @param #string filename
-- @return ShadowSprite#ShadowSprite ret (return value: cc.ShadowSprite)
        
--------------------------------
-- 
-- @function [parent=#ShadowSprite] createWithSpriteFrameName 
-- @param self
-- @param #string spriteFrameName
-- @return ShadowSprite#ShadowSprite ret (return value: cc.ShadowSprite)
        
--------------------------------
-- 
-- @function [parent=#ShadowSprite] createWithSpriteFrame 
-- @param self
-- @param #cc.SpriteFrame spriteFrame
-- @return ShadowSprite#ShadowSprite ret (return value: cc.ShadowSprite)
        
--------------------------------
-- 
-- @function [parent=#ShadowSprite] draw 
-- @param self
-- @param #cc.Renderer renderer
-- @param #mat4_table transform
-- @param #unsigned int flags
-- @return ShadowSprite#ShadowSprite self (return value: cc.ShadowSprite)
        
return nil
