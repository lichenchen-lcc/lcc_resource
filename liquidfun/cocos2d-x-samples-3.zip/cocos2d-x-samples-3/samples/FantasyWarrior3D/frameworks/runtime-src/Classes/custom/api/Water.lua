
--------------------------------
-- @module Water
-- @extend Sprite
-- @parent_module cc

--------------------------------
-- 
-- @function [parent=#Water] create 
-- @param self
-- @param #string tex1
-- @param #string tex2
-- @param #string tex3
-- @param #size_table size
-- @param #float hSpeed
-- @param #float vSpeed
-- @param #float saturation
-- @return Water#Water ret (return value: cc.Water)
        
return nil
