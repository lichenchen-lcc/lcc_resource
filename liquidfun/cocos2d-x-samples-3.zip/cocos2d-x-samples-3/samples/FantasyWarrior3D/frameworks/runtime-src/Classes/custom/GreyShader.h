//
//  GreyShader.h
//  cocos2d_libs
//
//  Created by Kirito on 10/22/14.
//
//

#ifndef __cocos2d_libs__GreyShader__
#define __cocos2d_libs__GreyShader__

#include "cocos2d.h"

USING_NS_CC;

NS_CC_BEGIN

class GreyShader : public Ref
{
public:
    static void setGreyShader(Sprite * s);
};

NS_CC_END
#endif /* defined(__cocos2d_libs__GreyShader__) */
