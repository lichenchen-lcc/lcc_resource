
--------------------------------
-- @module GreyShader
-- @extend Ref
-- @parent_module cc

--------------------------------
-- 
-- @function [parent=#GreyShader] setGreyShader 
-- @param self
-- @param #cc.Sprite s
-- @return GreyShader#GreyShader self (return value: cc.GreyShader)
        
return nil
