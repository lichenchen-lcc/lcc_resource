
--------------------------------
-- @module Effect3D
-- @extend Ref
-- @parent_module cc

--------------------------------
-- 
-- @function [parent=#Effect3D] draw 
-- @param self
-- @param #mat4_table transform
-- @return Effect3D#Effect3D self (return value: cc.Effect3D)
        
--------------------------------
-- 
-- @function [parent=#Effect3D] setTarget 
-- @param self
-- @param #cc.Sprite3D sprite
-- @param #cc.Mesh childMesh
-- @return Effect3D#Effect3D self (return value: cc.Effect3D)
        
return nil
