
--------------------------------
-- @module EffectSprite
-- @extend Sprite
-- @parent_module cc

--------------------------------
-- 
-- @function [parent=#EffectSprite] setEffect 
-- @param self
-- @param #cc.Effect effect
-- @return EffectSprite#EffectSprite self (return value: cc.EffectSprite)
        
--------------------------------
-- 
-- @function [parent=#EffectSprite] addEffect 
-- @param self
-- @param #cc.Effect effect
-- @param #int order
-- @return EffectSprite#EffectSprite self (return value: cc.EffectSprite)
        
--------------------------------
-- 
-- @function [parent=#EffectSprite] create 
-- @param self
-- @param #string filename
-- @return EffectSprite#EffectSprite ret (return value: cc.EffectSprite)
        
return nil
