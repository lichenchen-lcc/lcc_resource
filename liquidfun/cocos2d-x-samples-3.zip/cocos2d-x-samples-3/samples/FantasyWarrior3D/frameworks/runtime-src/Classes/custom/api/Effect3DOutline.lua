
--------------------------------
-- @module Effect3DOutline
-- @extend Effect3D
-- @parent_module cc

--------------------------------
-- 
-- @function [parent=#Effect3DOutline] setOutlineWidth 
-- @param self
-- @param #float width
-- @return Effect3DOutline#Effect3DOutline self (return value: cc.Effect3DOutline)
        
--------------------------------
-- 
-- @function [parent=#Effect3DOutline] setOutlineColor 
-- @param self
-- @param #vec3_table color
-- @return Effect3DOutline#Effect3DOutline self (return value: cc.Effect3DOutline)
        
--------------------------------
-- 
-- @function [parent=#Effect3DOutline] create 
-- @param self
-- @return Effect3DOutline#Effect3DOutline ret (return value: cc.Effect3DOutline)
        
--------------------------------
-- 
-- @function [parent=#Effect3DOutline] draw 
-- @param self
-- @param #mat4_table transform
-- @return Effect3DOutline#Effect3DOutline self (return value: cc.Effect3DOutline)
        
--------------------------------
-- 
-- @function [parent=#Effect3DOutline] setTarget 
-- @param self
-- @param #cc.Sprite3D sprite
-- @param #cc.Mesh childMesh
-- @return Effect3DOutline#Effect3DOutline self (return value: cc.Effect3DOutline)
        
return nil
