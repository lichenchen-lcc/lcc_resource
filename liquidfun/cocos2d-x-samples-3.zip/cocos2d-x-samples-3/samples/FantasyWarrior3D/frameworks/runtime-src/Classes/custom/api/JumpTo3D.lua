
--------------------------------
-- @module JumpTo3D
-- @extend JumpBy3D
-- @parent_module cc

--------------------------------
--  creates the action 
-- @function [parent=#JumpTo3D] create 
-- @param self
-- @param #float duration
-- @param #vec3_table position
-- @param #float height
-- @param #int jumps
-- @return JumpTo3D#JumpTo3D ret (return value: cc.JumpTo3D)
        
--------------------------------
-- 
-- @function [parent=#JumpTo3D] startWithTarget 
-- @param self
-- @param #cc.Node target
-- @return JumpTo3D#JumpTo3D self (return value: cc.JumpTo3D)
        
--------------------------------
-- 
-- @function [parent=#JumpTo3D] clone 
-- @param self
-- @return JumpTo3D#JumpTo3D ret (return value: cc.JumpTo3D)
        
--------------------------------
-- 
-- @function [parent=#JumpTo3D] reverse 
-- @param self
-- @return JumpTo3D#JumpTo3D ret (return value: cc.JumpTo3D)
        
--------------------------------
-- 
-- @function [parent=#JumpTo3D] JumpTo3D 
-- @param self
-- @return JumpTo3D#JumpTo3D self (return value: cc.JumpTo3D)
        
return nil
