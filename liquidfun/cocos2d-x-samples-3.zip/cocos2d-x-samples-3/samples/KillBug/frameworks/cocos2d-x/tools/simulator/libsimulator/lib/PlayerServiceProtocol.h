
#ifndef __PLAYER_SERVICE_PROTOCOL_H_
#define __PLAYER_SERVICE_PROTOCOL_H_

#include "PlayerMacros.h"

PLAYER_NS_BEGIN

class PlayerServiceProtocol
{
public:
    virtual ~PlayerServiceProtocol() {};
};

PLAYER_NS_END

#endif // __PLAYER_SERVICE_PROTOCOL_H_
