
#ifndef __PLAYER_MACROS_H_
#define __PLAYER_MACROS_H_

#define PLAYER_NS_BEGIN namespace player {
#define PLAYER_NS_END }
#define USING_PLAYER_NS using namespace player;

#endif // __PLAYER_MACROS_H_
