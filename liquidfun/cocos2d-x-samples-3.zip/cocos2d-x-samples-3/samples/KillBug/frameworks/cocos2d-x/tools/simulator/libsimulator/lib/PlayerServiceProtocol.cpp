
#include "PlayerServiceProtocol.h"

PLAYER_NS_BEGIN

PLAYER_NS_END
