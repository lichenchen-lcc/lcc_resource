# Content License

Portions of this documentation are modifications based on work
created and shared by Erin Catto and used according to terms
described in the
[Creative Commons 4.0 Attribution License](http://creativecommons.org/licenses/by/4.0/legalcode)

Copyright © 2007-2011 Erin Catto

Copyright © 2013-2014 Fun Propulsion Labs at Google

