.. cmake-module:: ../../Modules/FindBoost.cmake
