.. cmake-module:: ../../Modules/FindProtobuf.cmake
