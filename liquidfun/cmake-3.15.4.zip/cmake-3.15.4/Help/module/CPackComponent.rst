.. cmake-module:: ../../Modules/CPackComponent.cmake
