
cc.geomUtils = {
    Triangle: require('./triangle'),
    Aabb: require('./aabb'),
    Ray: require('./ray'),
    intersect: require('./intersect')
};

export default cc.geomUtils
