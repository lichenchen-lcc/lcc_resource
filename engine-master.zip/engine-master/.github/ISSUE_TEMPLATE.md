<!--
    EN: Here only receive bug report or suggestions for improvement. Feature request please send to the forum: http://discuss.cocos2d-x.org/c/creator
    中: 这里只接收 bug 反馈或改进建议。新功能需求请发到论坛：https://forum.cocos.com/c/Creator
-->

### Creator version?（版本号）


### Affected platform?（受影响的平台）
<!-- Mac Editor / Windows Editor / Web / iOS / Android / Simulator ... -->

### How to reproduce?（如何重现）


### JavaScript output or error produced?（报错信息和调用栈）
<!--
    EN: The error must be the first error when the problem occurred.
    中：这里填写的报错信息必须是出现问题时的第一个报错。
-->

### Demo project?（demo 项目）
<!--
    EN: A complete parsable Creator project or resources exhibiting the issue with Creator alone - without third party tools or libraries or server. Ideally the demo should be as small as possible.
    It is very likely that issues without a reproducible test case will be closed.

    中：用于呈现错误的可理解的 Creator 工程或资源，不依赖第三方工具或插件或者服务端。这个 demo 应该越小越好。
    不含可重现范例的 issue 将有可能被关闭。
-->

<!--
### Thanks for the feedback.（感谢反馈）
-->
