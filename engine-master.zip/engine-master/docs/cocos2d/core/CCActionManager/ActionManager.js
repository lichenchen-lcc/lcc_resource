----
var mng = new cc.ActionManager();
