------------------
var key = cc.textureCache.textureForKey("hello.png");
