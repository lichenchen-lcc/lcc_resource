---------------
var cacheTextureForColor = cc.textureCache.getTextureColors(texture);
