--------
cc.textureCache.removeAllTextures();
