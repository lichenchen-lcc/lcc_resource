------------------
var key = cc.textureCache.getTextureForKey("hello.png");
