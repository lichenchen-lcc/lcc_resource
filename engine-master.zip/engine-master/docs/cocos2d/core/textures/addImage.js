----
cc.textureCache.addImage("hello.png");
