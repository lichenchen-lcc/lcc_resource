------
cc.textureCache.removeTexture("hello.png");
