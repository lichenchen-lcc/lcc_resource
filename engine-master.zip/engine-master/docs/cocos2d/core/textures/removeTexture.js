-----
cc.textureCache.removeTexture(texture);
