--------------------------------------------------
var textureAtlas = new cc.TextureAtlas();
textureAtlas.initWithTexture("hello.png", 3);
