---------
var key = cc.textureCache.getKeyByTexture(texture);
