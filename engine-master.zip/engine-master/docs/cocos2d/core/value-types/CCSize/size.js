var size1 = cc.size();
var size2 = cc.size(100,100);
var size3 = cc.size(size2);
var size4 = cc.size({width: 100, height: 100});
