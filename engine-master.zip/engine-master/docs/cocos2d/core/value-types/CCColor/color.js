-----------------------
// 1. All channels seperately as parameters
var color1 = new cc.Color(255, 255, 255, 255);
// 2. Convert a hex string to a color
var color2 = new cc.Color("#000000");
// 3. An color object as parameter
var color3 = new cc.Color({r: 255, g: 255, b: 255, a: 255});
