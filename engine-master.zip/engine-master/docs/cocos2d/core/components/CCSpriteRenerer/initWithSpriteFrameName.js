---------
var sprite = new _ccsg.Sprite();
sprite.initWithSpriteFrameName("grossini_dance_01.png");
