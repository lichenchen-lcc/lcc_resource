----------------------------------------------------
//get a SpriteFrame by name
var frame = cc.spriteFrameCache.getSpriteFrame("grossini_dance_01.png");
