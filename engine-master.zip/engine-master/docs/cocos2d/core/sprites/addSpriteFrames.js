----------------------------------------------------
// add SpriteFrames to SpriteFrameCache With File
cc.spriteFrameCache.addSpriteFrames(s_grossiniPlist);
cc.spriteFrameCache.addSpriteFrames(s_grossiniJson);
