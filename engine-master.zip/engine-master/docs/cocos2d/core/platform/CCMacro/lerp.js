----
lerp
cc.misc.lerp(2,10,0.5)//returns 6
cc.misc.lerp(2,10,0.2)//returns 3.6
