node.setPosition(cc.v2(0, 0));
node.setPosition(0, 0);
