---------------------------------
var size = cc.winSize;
node.setPosition(size.width/2, size.height/2);
