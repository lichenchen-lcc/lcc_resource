---------------------------------
cc.path.changeExtname("a/b.png", ".plist");		//-->"a/b.plist"
cc.path.changeExtname("a/b.png?a=1&b=2", ".plist");	//-->"a/b.plist?a=1&b=2"
