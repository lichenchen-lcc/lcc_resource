//unschedules the "update" method.
var scheduler = cc.director.getScheduler();
scheduler.unscheduleUpdateForTarget(this);
