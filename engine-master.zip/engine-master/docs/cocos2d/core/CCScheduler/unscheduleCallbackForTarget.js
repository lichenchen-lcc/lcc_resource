//unschedule a callback of target
var scheduler = cc.director.getScheduler();
scheduler.unscheduleCallbackForTarget(this, callback);
